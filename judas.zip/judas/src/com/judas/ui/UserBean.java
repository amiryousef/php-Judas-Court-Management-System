package com.judas.ui;

public class UserBean {
	
	private String username;
    private String password;
    private String firstName;
    private String lastName;
    private String userType;
    public boolean valid;
	


	public UserBean() {
		// TODO Auto-generated constructor stub
	}
	
	
    public String getFirstName() {
       return firstName;
	}

    public void setFirstName(String newFirstName) {
       firstName = newFirstName;
	}

	
    public String getLastName() {
       return lastName;
	}

    public void setLastName(String newLastName) {
       lastName = newLastName;
	}
			

    public String getPassword() {
       return password;
	}

    public void setPassword(String newPassword) {
       password = newPassword;
	}
	
			
    public String getUsername() {
       return username;
	}

    public void setUserName(String newUsername) {
       username = newUsername;
	}

				
    public boolean isValid() {
       return valid;
	}

    public void setValid(boolean newValid) {
       valid = newValid;
	}	

    public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}
}
