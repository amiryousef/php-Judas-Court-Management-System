package com.judas.ui;

public class Constants {
	public final static String CLERK = "clerk";

}
