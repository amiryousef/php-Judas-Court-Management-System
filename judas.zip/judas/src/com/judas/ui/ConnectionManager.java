package com.judas.ui;

import java.sql.*;


   public class ConnectionManager {

	  static Connection con = null;
      static String dbURL = "jdbc:mysql://localhost/judas";
            
      public static Connection getConnection() {
        
         try {
        	 con = DriverManager.getConnection(dbURL, "root", "");           
         } catch(SQLException e) {
            System.out.println(e);
         }

      return con;
}
   }