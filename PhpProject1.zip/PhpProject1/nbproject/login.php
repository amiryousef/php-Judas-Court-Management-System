<?php
require("config.php");

if (isset($_POST['submit'])){ 
    if ($_POST['username'] == "" )
        {
        header("Location: ./noData.php");
        exit();
        }
    else if ($_POST['password'] == "" )
        {
        header("Location: ./noData.php");
        exit();
        }
     else{ 
        // email and password from the form
         $loginEmail = mysql_real_escape_string($_POST['username']);
         $loginPassword =  hash("sha512", mysql_real_escape_string($_POST['password'])); 
     }
     
}

?>
