<?php
require("login.php");
        
print("<h1>You didn't enter any Data</h1>");

?>
