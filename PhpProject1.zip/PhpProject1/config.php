<?php
$angela = 0;
$bonnie = 1;
    if ($angela){
         $dbhost = "dbsrv2.cs.fsu.edu";
         $dbuser = "reaves";
         $dbpass = "t7TT32@2o5";
         $dbDatabase = "judas";
    }else if ($bonnie){
        $dbUser = "root";
        $dbPass = "";
        $dbDatabase = "judas";
        $dbHost = "localhost";
    }else {
        $dbUser = "root";
        $dbPass = "";
        $dbDatabase = "test1";
        $dbHost = "localhost"; 
    }

$dbConn = mysql_connect($dbHost, $dbUser, $dbPass);

if ($dbConn) {
    mysql_select_db($dbDatabase);
}  else {
    die("<strong>Error: could not connect to database.</strong>");
}

?>
