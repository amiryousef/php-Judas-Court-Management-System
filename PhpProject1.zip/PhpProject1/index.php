<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Judas Login</title>
    </head>
    <body>
        <?php
        require("RunLogin.php");
        print("<form id =\"loginForm\" method=\"post\" action=\"./login.php\">\n");
        print("Email: <input type=\"text\" name=\"login\" id=\"login\"/><br /><br />\n");
        print("Password: <input type=\"password\" name=\"password\" id=\"password\"/><br /><br />\n"); 
       
        print("<br/> <button type=\"submit\" name=\"submitted\" id=\"submitted\">Login</button>\n");
        print("</form>\n");
        ?>
       </body> 
</html>
