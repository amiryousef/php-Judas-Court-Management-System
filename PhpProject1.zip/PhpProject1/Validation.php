<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Validation
 *
 * @author dellguest
 */
class Validation{
    
  function checkForInput(){
    if ($_POST['login'] == "" ){
    return false;}
    else if ($_POST['password'] == "" ){
    return false;}
    else {return true;}
   }
   
  function SetUserName() {
      return mysql_real_escape_string($_POST['login']);
    }
  
  function SetUserPassword(){
      //return hash("sha512", mysql_real_escape_string($_POST['password'])); 
      return mysql_real_escape_string($_POST['password']);
  }
  
  function SetQuery($login,$password){
    
        return $query = mysql_query ("SELECT user.firstName, user.lastName, user.userID, user.login, login.password from user, login "
              . " WHERE user.userID = login.userID AND user.login = '". $login ."' AND login.password = '".$password. "'");    
    }// end SetQuery()
  
  function SetRole($userID){
      //Search the role_type and user_role tables for the specific user's job
    
    $query = mysql_query("SELECT user_role.roleID, role_type.roleName, "
             . "role_type.roleDescription FROM user_role, role_type "
             . "WHERE user_role.userID = '$userID' "
             . "AND role_type.roleID = '$userID'");
    
    if (mysql_num_rows($query)){   //test that a query is found
          return  $roleRow = mysql_fetch_array($query);    
      } else {
           echo "<br/>SetRole() = no role type in the role table";
           return $query = FALSE;
       }
  }
        function AddInvalidUser(){

        $ipAddress = $_SERVER["REMOTE_ADDR"];
        $attempt = '1';
       mysql_query("INSERT INTO `invalid_login`(`ip_address`, `attempt`) VALUES ('".$ipAddress."','".$attempt."')");
    }
    function CheckInvalidList(){
       //get ip address and see if it has been recorded, return attempt or now record
        
       $ipAddress = $_SERVER["REMOTE_ADDR"];
       $query = mysql_query("SELECT `ip_address`, 'attempt' FROM `invalid_login` WHERE `ip_address` = '" . $ipAddress . "'" );
        
       if(mysql_num_rows($query))
        {
            $row = mysql_fetch_array($query);
            return $attempt = $row['attempt'];
         }else{
             return $query = 0;
         }
    }// end of CheckInvalidList
    
 }// end of validation class
?>
