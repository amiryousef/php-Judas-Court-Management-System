<?php
require("RunLogin.php");
print("<h1>congrats, we are logged in!</h1>");

?>
