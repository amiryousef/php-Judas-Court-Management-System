<?php
require("RunLogin.php");
/* 
 *  This file uses config.php to configure the db setup.  choose angela or bonnie
 *  to set the correct db user in the config.php file.
 * 
 *  This file creates an object from the Validation.php class and uses the 
 *  Validation.php file. 
 * 
 *  Run.configure.php starts the session 
 * 
 * 
 */

 // Run the classes: 
 
 if (isset($_POST['submitted'])){ 
  
     //create an object to do valiation of input
    $a = new Validation() ;
    if (!$a->checkForInput()){  
        echo"<br/>No input entered";
       }else{
       
// set the login and password variables to what the user entered
       
        if ( $a->CheckInvalidList() < 5){
        $login = $a->SetUserName();
        $password = $a->SetUserPassword();
        
      // see if user is in the database    
        $query = $a ->SetQuery($login,$password);
        
        if(mysql_num_rows($query)) {    
            // there is a user, you can go to the user login home screen
            echo "You entered a valid Login!";
            $row = mysql_fetch_array($query);
            $userID = $row['userID'];
            echo "<br/>Hello ". $row['firstName'];
        
   // Get user type (clerk, lawyer, admin, judge)       
            $role = $a->SetRole($userID);           
           
           echo "<br/>You are a : ". $role['roleName'] ;
           echo "  which:  ". $role['roleDescription'];
            
         }else{
        echo"<br/>You are not an active user.";
        $a->AddInvalidUser();
        }//end else mysql_num_row
       }else{
           echo"<br/>You have exceed your invalid login attempts";
       }// if else for checkinvalidlist
 
  }
 }
      
?>
