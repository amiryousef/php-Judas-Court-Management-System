<?php

session_start();

require("config.php"); // Include the db connection
require("Validation.php");

//To check if a user is logged in




?>
